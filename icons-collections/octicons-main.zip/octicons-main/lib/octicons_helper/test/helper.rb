require "minitest/autorun"
require "octicons_helper"

include OcticonsHelper
