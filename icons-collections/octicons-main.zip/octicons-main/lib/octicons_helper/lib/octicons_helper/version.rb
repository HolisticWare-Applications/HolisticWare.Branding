module OcticonsHelper
  VERSION = "19.1.0".freeze
end
