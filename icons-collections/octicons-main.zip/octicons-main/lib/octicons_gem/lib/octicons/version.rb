module Octicons
  VERSION = "19.1.0".freeze
end
