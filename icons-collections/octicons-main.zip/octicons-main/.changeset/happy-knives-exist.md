---
"@primer/octicons": minor
---

Add `id`, `title`, and `aria-labelledby` props to icon components
