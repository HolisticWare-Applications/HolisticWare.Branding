# react-icons demo

## how to develop

```
$ yarn
$ yarn start
```
