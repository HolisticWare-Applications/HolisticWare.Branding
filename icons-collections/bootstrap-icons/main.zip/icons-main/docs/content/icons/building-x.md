---
title: Building x
categories:
  - Buildings
tags:
  - company
  - enterprise
  - organization
  - office
  - business
---
