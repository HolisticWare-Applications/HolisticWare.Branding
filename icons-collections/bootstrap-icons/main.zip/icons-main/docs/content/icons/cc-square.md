---
title: CC square
categories:
  - Shapes
tags:
  - "creative commons"
---
