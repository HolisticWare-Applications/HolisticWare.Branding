---
title: 0 circle
categories:
  - Shapes
tags:
  - number
  - numeral
---
